Instructions for compiling and running code:

- place all files in a directory together.
- move to that directory from the command line.
- run the make utility.
- from the CLI run ./ACS200009MyLock:
	+ the code will request an input for which lock you desire, 0 for Tournament Tree Lock
	+ the code will request an input for the desired value of n, which specifies the number of threads or processes the user wants to generate (we're using threads).
	+ the code will output a final counter value commiserate with the function that's being asked to run. 
